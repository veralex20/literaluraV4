package com.example.literaluraV4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraluraV4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
